package com.waa.labtwo.dto;

import lombok.Data;

@Data
public class UserDto {
    long id;
    String name;
}
