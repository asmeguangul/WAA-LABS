package com.waa.labtwo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaboneApplication {

    public static void main(String[] args) {

        SpringApplication.run(LaboneApplication.class, args);
    }

}
