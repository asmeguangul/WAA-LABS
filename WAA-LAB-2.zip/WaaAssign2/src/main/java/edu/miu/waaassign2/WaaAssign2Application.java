package edu.miu.waaassign2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WaaAssign2Application {

    public static void main(String[] args) {
        SpringApplication.run(WaaAssign2Application.class, args);
    }

}
