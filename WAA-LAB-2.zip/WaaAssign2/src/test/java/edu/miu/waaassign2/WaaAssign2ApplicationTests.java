package edu.miu.waaassign2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WaaAssign2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
