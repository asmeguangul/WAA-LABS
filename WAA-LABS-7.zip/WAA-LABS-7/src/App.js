import logo from './logo.svg';
import './App.css';
import Posts from './dashboard/Posts';
import Update from './dashboard/Update';
import './dashboard/dashboard.css';
import { useState } from 'react';

function App() {
  const post = [
    { id: 111, title: "Happiness", author: "John" },
    { id: 112, title: "MIU", author: "Dean" },
    { id: 113, title: "Enjoy Life", author: "Jasmine" }
]
  const[postsList,setPostList]= useState(post)
  const titleHandler=(title)=>{
   const post =[...postsList]
   post[0].title = title;
  setPostList(post);
  }
  return (
     <>
    <Posts postList={postsList}/>
     <Update  titleHandler={titleHandler}/>
    </>
  );
}

export default App;
