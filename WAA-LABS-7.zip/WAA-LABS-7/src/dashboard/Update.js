import React, { useState } from 'react'
import Post from '../dashboard/Post'

export default function Update(props) {
   
const [title, setTitle]= useState('');

    return (
        <div>
            <input type="text" id="input" value={title} onChange={(e)=>setTitle(e.target.value)}></input><br />
            <button onClick={()=>props.titleHandler(title)}>Change Name</button>
        </div>
    )
}
