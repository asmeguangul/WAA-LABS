import React from 'react'

export default function Post(props) {
  return (
    <div className="Content">
       <h4>ID:{props.id}</h4>
       <h4>Title:{props.title}</h4>
       <h4>Author:{props.author}</h4>
    </div>
  )
}


