import React from 'react'
import Post from './Post'

export default function Posts(props) {

    const postsList = [
        { id: 111, title: "Happiness", author: "John" },
        { id: 112, title: "MIU", author: "Dean" },
        { id: 113, title: "Enjoy Life", author: "Jasmine" }
    ]

    const list = props.postList.map(p => <Post id={p.id} key={p.id} 
                                            title={p.title} author={p.author} />)


    return (
        list
     )
    }
