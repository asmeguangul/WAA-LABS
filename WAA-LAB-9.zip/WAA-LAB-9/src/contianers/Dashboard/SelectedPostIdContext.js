import { createContext } from "react";

const SelectedPostIdContext = createContext(0);

export default SelectedPostIdContext;
