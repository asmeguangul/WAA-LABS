package com.studywaa.waalabw11.dto;

import lombok.Data;

@Data
public class SimplePostDto {
    private long id;
    private String title;
}


//package edu.miu.restful.dto;
//
//        import lombok.Data;
//        import lombok.Getter;
//        import lombok.Setter;
//
//@Data
//public class SimpleProductDto {
//    private float price;
//    private String name;
//}