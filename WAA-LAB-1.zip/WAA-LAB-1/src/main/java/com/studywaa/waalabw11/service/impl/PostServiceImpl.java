package com.studywaa.waalabw11.service.impl;

import com.studywaa.waalabw11.entity.Post;
import com.studywaa.waalabw11.repo.PostRepo;
import com.studywaa.waalabw11.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service


public class PostServiceImpl implements PostService {
    @Autowired
   private PostRepo postRepo;

    @Override
    public List<Post> findAll() {
        return postRepo.findAll();
    }

    @Override
    public Post getById(long id) {
         return postRepo.getById(id);
    }

    @Override
    public void save(Post p) {
      postRepo.save(p);
    }

    @Override
    public void delete(long id) {
        postRepo.delete(id);

    }

    @Override
    public void update(long id, Post p) {
        postRepo.update(id,p);

    }
}



