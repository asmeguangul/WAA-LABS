package com.studywaa.waalabw11.repo;

import com.studywaa.waalabw11.entity.Post;

import java.util.List;

public interface PostRepo {
    public List<Post> findAll();
    public Post getById(long id);
    public void save(Post p);
    public void delete(long id);
    public void update(long id, Post p);
}


