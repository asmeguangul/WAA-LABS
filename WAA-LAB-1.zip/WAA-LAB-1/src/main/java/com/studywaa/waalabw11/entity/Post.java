package com.studywaa.waalabw11.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class Post
{
    private long id;
    private String title;
    private String content;
    private String author;
}




