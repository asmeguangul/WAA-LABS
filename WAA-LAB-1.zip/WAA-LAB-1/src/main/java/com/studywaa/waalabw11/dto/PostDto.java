package com.studywaa.waalabw11.dto;

import lombok.Data;

@Data
public class PostDto {
    private long id;
    private String title;
    private String author;
}


